package mine.spring.sample1;

public interface HelloWorld {
	String hello(String msg);
}
