package mine.spring.sample;

public interface HelloWorld {
	String hello(String msg);
}
