package mine.sample.concurrent.highlevel;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MyBlockingQueue {

	public static void main(String[] args) {
		ExecutorService exeSrv = Executors.newSingleThreadExecutor();
	}
	
	
}
