package mine.sample.concurrent.locks;

public class StampedLockDemo implements Runnable {

	@Override
	public void run() {

	}

}
