import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;


public class preparedst_example {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
	      
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott", "tiger");
		System.out.println("hello");
			PreparedStatement pst=con.prepareStatement("select * from dept where deptno=?");
			
			for(int i=1;i<5;i++)
			{
				pst.setInt(1, i*10);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
					System.out.println(rs.getString(2));
		
				rs.close();
			}	
		pst.close();
		con.close();
		

	}

}
