import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.CallableStatement;


public class callable_st_example {

	/**
	 * @param args
	 */
	public static void main(String[] args)throws Exception {
	      
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott", "tiger");
		System.out.println("hello");
		CallableStatement 
		st=con.prepareCall("{ call example()}");
		st.execute();
		
		st=con.prepareCall("{ call example(?)}");
		st.setInt(1, 5);
		st.execute();
		
		st.close();
		con.close();
		

	}

}
