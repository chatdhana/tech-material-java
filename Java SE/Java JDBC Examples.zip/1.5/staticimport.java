

import static java.lang.Math.*;
public class staticimport {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		System.out.println(PI);
	}

}
