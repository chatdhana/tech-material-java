import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;


public class DatabaseMetaData_Example {
	public static void main(String[] args)throws Exception {
	      
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott", "tiger");
		DatabaseMetaData dmd=con.getMetaData();
		System.out.println(dmd.getDatabaseProductName());
		System.out.println(dmd.getJDBCMajorVersion()   );
		con.close();
		

	}

}